// Task 2 //
#include "Header.h"
int main() {
	// Showing any 2 Functions //

	Freshman f("haseeb", 20, "Computer Science");
	f.displayInfo();
	cout << endl;

	DoctoralStudent d("Hassan", 27, "Chemical Engineer");
	d.displayInfo();

	system("pause");
	return 0;
}