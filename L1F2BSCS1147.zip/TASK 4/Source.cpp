// Task 4 //
#include "Header.h"
int main() {
	TeachingAssistant ta;
	ta.setName("ABDUL REHMAN");
	ta.setAge(20);
	ta.setMajor("Computer Science");
	ta.setSalary(70000);
	ta.subject = "Programming";

	ta.displayTeachingAssistantInfo(ta);
	
	system("pause");
	return 0;
}
